package com.cg.library;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import oracle.net.aso.e;

public class DeleteQuery {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Library");

		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		int a=15;
		Library lib = em.find(Library.class,a);
		//	Query q = em.createQuery("delete from Library l1 where id=15");
		//q.setInt(id);
		
		em.remove(lib);
		em.getTransaction().commit();
		em.close();
		emf.close();
	}

}
