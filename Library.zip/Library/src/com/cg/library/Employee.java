package com.cg.library;

import javax.persistence.Entity;
@Entity
public class Employee extends Person {

	public Employee(int id, String name) {
		super(id, name);
		// TODO Auto-generated constructor stub
	}
	

	public Employee(int id, String name, double salary) {
		super(id, name);
		this.salary = salary;
	}

	private double salary;

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	public Employee()
	{
		
	}
	
	
}
