package com.cg.library;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class UpdateQuery {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Library");

		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		System.out.println("Enter id Details");
		Scanner sc = new Scanner(System.in);
		int book = sc.nextInt();
		
		//Library l1 = new Library();
		
		Library l2 = em.find(Library.class, book);
		if(l2==null)
		{
			System.out.println("Not found");
		}
		else
		{
			System.out.println("Enter Name Details");
			String a = sc.next();
			System.out.println("Enter New Price");
			double b = sc.nextDouble();
			l2.setBookName(a);
			l2.setBookPrice(b);
			em.persist(l2);

		}
		em.getTransaction().commit();
		em.close();
		emf.close();
		sc.close();

	}

}
