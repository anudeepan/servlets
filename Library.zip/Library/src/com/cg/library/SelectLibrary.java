package com.cg.library;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class SelectLibrary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Library");

		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		
		Query q = em.createNamedQuery("select_library");
		List<Library> list = q.getResultList();
		for(Library lib : list)
		{
			System.out.println("----------------");
			System.out.println("id:" +lib.getId());
			System.out.println("id:" +lib.getBookName());
			System.out.println("id:" +lib.getBookPrice());
		}
	}

}
