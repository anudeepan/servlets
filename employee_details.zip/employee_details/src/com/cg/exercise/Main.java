package com.cg.exercise;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Employee------------------------------");
		

AddEmployee ae = new AddEmployee();
DeleteQuery dq = new DeleteQuery();
SearchById sei = new SearchById();
UpdateQuery uq = new UpdateQuery();
UserDetails ud = new UserDetails();
ViewDetails vd =  new ViewDetails();
	
		System.out.println("1.Add");
		System.out.println("2.Update");
		System.out.println("3.Delete");
		System.out.println("4.View");
		System.out.println("5.Search By Id");
		System.out.println("6.Exit");
		
		Scanner sc = new Scanner(System.in);
		
		int menu=sc.nextInt();
		while(menu<6)
		{
			switch(menu)
			{
			case 1:ae.AddEmployee();break;
			case 2:mn.withdraw();break;
			case 3:mn.check();break;
			case 4:ab.
			
			case 4:System.exit(0);
			}
		}
		
	}
}

		
	}

}
