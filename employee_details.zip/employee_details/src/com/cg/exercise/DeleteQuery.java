package com.cg.exercise;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.exercise.UserDetails;

public class DeleteQuery {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("employee_details");

		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		int a=1;
		UserDetails lib = em.find(UserDetails.class,a);
		//	Query q = em.createQuery("delete from Library l1 where id=15");
		//q.setInt(id);
		
		em.remove(lib);
		em.getTransaction().commit();
		em.close();
		emf.close();
		
		
	}

}
