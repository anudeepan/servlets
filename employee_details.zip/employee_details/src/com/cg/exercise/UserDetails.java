package com.cg.exercise;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name="Employee_details")
@TableGenerator(name="ta_seq",initialValue=1,allocationSize=1)
public class UserDetails {
//	private static final String ename = null;
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE, generator="ta_seq")
	private int id;
	@Column(name="ename")
	private String name;
	@Column(name="esal")
	private double salary;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
}
