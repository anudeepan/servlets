package com.cg.exercise;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import com.cg.exercise.UserDetails;

public class UpdateQuery {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		EntityManagerFactory emf = Persistence.createEntityManagerFactory("employee_details");

		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		System.out.println("Enter Book Details");
		Scanner sc = new Scanner(System.in);
		int id = sc.nextInt();
		
		//Library l1 = new Library();
		
		UserDetails l2 = em.find(UserDetails.class, id);
		if(l2==null)
		{
			System.out.println("Not found");
		}
		else
		{
			System.out.println("Enter Name Details");
			String a = sc.next();
			System.out.println("Enter New Price");
			double b = sc.nextDouble();
			l2.setName(a);
			l2.setSalary(b);
			em.persist(l2);

		}
		em.getTransaction().commit();
		em.close();
		emf.close();
		sc.close();

		
	}

}
