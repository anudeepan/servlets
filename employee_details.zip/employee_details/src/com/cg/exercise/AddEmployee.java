package com.cg.exercise;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.exercise.UserDetails;

public class AddEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("employee_details");

		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		
		UserDetails l1 = new UserDetails();
		l1.setName("Java");
		l1.setSalary(399.00);

		UserDetails l2 = new UserDetails();
		l2.setName("Angular");
		l2.setSalary(1399.00);
		em.persist(l1);
		em.persist(l2);
		
		
		em.getTransaction().commit();
		em.close();
		emf.close();
		
		
		
		
		
	}

}
