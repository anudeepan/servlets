package com.cg.exercise;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class SearchById {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("employee_details");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		Scanner sc = new Scanner(System.in);
		int id = sc.nextInt();
		UserDetails l2 = em.find(UserDetails.class, id);
		if(l2==null)
		{
			System.out.println("Not there");
		}else
		{
			l2.getId();
			l2.getName();
			l2.getSalary();
			System.out.println("----------------");
			System.out.println("id:" +l2.getId());
			System.out.println("id:" +l2.getName());
			System.out.println("id:" +l2.getSalary());
		}
		sc.close();
	}
}
