package com.cg.exercise;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.exercise.UserDetails;

public class ViewDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("employee_details");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		Query q = em.createQuery("select l1 from UserDetails l1");
		List<UserDetails> list = q.getResultList();
		for(UserDetails lib : list)
		{
			System.out.println("----------------");
			System.out.println("id:" +lib.getId());
			System.out.println("id:" +lib.getName());
			System.out.println("id:" +lib.getSalary());
		}
	}

	}


